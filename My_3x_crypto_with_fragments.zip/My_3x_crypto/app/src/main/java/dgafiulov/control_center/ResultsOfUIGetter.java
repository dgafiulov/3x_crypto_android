package dgafiulov.control_center;

import androidx.viewbinding.ViewBinding;

public class ResultsOfUIGetter {

    ViewBinding binding;

    public ResultsOfUIGetter(ViewBinding binding) {
        this.binding = binding;
    }

    public boolean getSwitchResult() {
        //return binding.swChoose.isChecked();
        return true;
    }

    public String getPasswordFromEditText() {
        //return binding.etPasswordInput.getText().toString();
        return "aaa";
    }
}
