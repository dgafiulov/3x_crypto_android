package dgafiulov.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.viewbinding.ViewBinding;

import dgafiulov.ui.databinding.FragmentDecodeInNewVersionsBinding;

public class DecodeInNewVersionsFragment extends Fragment {

    FragmentDecodeInNewVersionsBinding binding;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentDecodeInNewVersionsBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    public ViewBinding getBinding() {
        return binding;
    }
}