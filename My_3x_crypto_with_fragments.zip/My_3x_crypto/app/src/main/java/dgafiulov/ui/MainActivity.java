package dgafiulov.ui;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.viewbinding.ViewBinding;

import dgafiulov.control_center.ControlCenter;
import dgafiulov.ui.databinding.ActivityMainBinding;
import dgafiulov.ui.databinding.FragmentDecodeInNewVersionsBinding;
import dgafiulov.ui.databinding.FragmentDecodeInOldVersionsBinding;
import dgafiulov.ui.databinding.FragmentEncodeBinding;

public class MainActivity extends AppCompatActivity {

    ControlCenter controlCenter;
    ActivityMainBinding binding;
    Fragment currentFragment;
    FragmentEncodeBinding fragmentEncodeBinding;
    FragmentDecodeInNewVersionsBinding fragmentDecodeInNewVersionsBinding;
    FragmentDecodeInOldVersionsBinding fragmentDecodeInOldVersionsBinding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        controlCenterInit(fragmentsInit());
    }

    private void bindingInit() {
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
    }

    private ViewBinding fragmentsInit() {
        currentFragment = getSupportFragmentManager().findFragmentById(R.id.fragment_container_view);

        if (currentFragment instanceof EncodeFragment) {
            EncodeFragment encodeFragment = (EncodeFragment) currentFragment;
            FragmentEncodeBinding bind = (FragmentEncodeBinding) encodeFragment.getBinding();
            encodeFragment.btChooseFileSetOnClickListener(this, controlCenter.getFileGetter(), controlCenter);
            encodeFragment.btStartSetOnClickListener(this, controlCenter.getFileGetter(), controlCenter);
            return bind;
        } else if (currentFragment instanceof DecodeInNewVersionsFragment) {
            DecodeInNewVersionsFragment decodeInNewVersionsFragment = (DecodeInNewVersionsFragment) currentFragment;
            return decodeInNewVersionsFragment.getBinding();
        } else if (currentFragment instanceof DecodeInOldVersionsFragment) {
            DecodeInOldVersionsFragment decodeInOldVersionsFragment = (DecodeInOldVersionsFragment) currentFragment;
            return decodeInOldVersionsFragment.getBinding();
        }

        return null; //when nothing found
    }
    private void controlCenterInit(ViewBinding binding) {
        controlCenter = new ControlCenter(binding, MainActivity.this, getApplicationContext());
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == controlCenter.getChooseFileCode()) {
            controlCenter.getFile(requestCode, resultCode, data, this);
        } else if (requestCode == controlCenter.getSaveFileCode()) {
            Log.i(String.valueOf(Log.INFO), "on activity result");
            controlCenter.changeAndSaveFile(resultCode, data);
        }
    }
}