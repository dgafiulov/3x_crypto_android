package dgafiulov.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.viewbinding.ViewBinding;

import dgafiulov.ui.databinding.FragmentDecodeInOldVersionsBinding;

public class DecodeInOldVersionsFragment extends Fragment {

    FragmentDecodeInOldVersionsBinding binding;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentDecodeInOldVersionsBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    public ViewBinding getBinding() {
        return binding;
    }
}