package dgafiulov.ui;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.viewbinding.ViewBinding;

import dgafiulov.control_center.ControlCenter;
import dgafiulov.ui.databinding.FragmentEncodeBinding;
import dgafiulov.worker_files.FileGetter;

public class EncodeFragment extends Fragment {

    private FragmentEncodeBinding binding;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentEncodeBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    public ViewBinding getBinding() {
        return binding;
    }

    public void btChooseFileSetOnClickListener(Activity mainActivity, FileGetter fileGetter, ControlCenter controlCenter) {
        binding.btChooseFile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //fileGetter.openFileChooser(view);
                Log.i(String.valueOf(Log.INFO), "help");
                mainActivity.startActivityForResult(fileGetter.getIntentForFileChooser(view), controlCenter.getChooseFileCode());
            }
        });
    }

    public void btStartSetOnClickListener(Activity mainActivity, FileGetter fileGetter, ControlCenter controlCenter) {
        binding.btStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (fileGetter.getFileUri() != null & !binding.etPasswordInput.getText().equals("")) {
                    try {
                        fileGetter.intentForFileSave(mainActivity);
                    } catch (Exception e) {
                        //workWithDialogs.getErrorDialog(mainActivity).show();
                    }
                }
            }
        });
    }
}